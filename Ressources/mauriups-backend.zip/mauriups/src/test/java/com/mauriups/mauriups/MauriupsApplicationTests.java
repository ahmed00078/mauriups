package com.mauriups.mauriups;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MauriupsApplicationTests {

	@Test
	void contextLoads() {
	}

}
